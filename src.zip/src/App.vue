<script>
import TodoList from './components/todoList/TodoList.vue'

export default {
  components: {
    TodoList
  }
}
</script>

<template>
  <main><TodoList /></main>
</template>

<style scoped></style>
